package oop.group.assignment;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Driver {

    static Scanner input = new Scanner(System.in);

    public static void main(String[] args) {
        Menu();
    }

    private static void Menu() {
        int logChoice = 0;

        System.out.println((char) 27 + "[33m▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀" + (char) 27 + "[0m");
        System.out.println((char) 27 + "[0m" + (char) 27 + "[30m\t\t                 Parking & Vehicle Management Systems                            " + (char) 27 + "[0m");
        System.out.println((char) 27 + "[33m▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄" + (char) 27 + "[0m");
        Calendar calender = Calendar.getInstance();
        SimpleDateFormat dateformatter = new SimpleDateFormat(" dd MMMMMMMMM',' yyyy ");
        System.out.println((char) 27 + "[31m                                           Date - " + (char) 27 + "[0m" + dateformatter.format(calender.getTime()));

        System.out.println((char) 27 + "[33m▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀" + (char) 27 + "[0m");
        System.out.println("1. Administrator                ");
        System.out.println("2. Login Normal                ");
        System.out.println("3. Quit                  ");
        System.out.println((char) 27 + "[33m▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀" + (char) 27 + "[0m");
        System.out.print((char) 27 + "[31mEnter Log In Choice: " + (char) 27 + "[0m");
        logChoice = input.nextInt();

        switch (logChoice) {
            case 1:
                Login("33", "ADMIN");
                break;
            case 2:
                Login("36", "NORMAL");
                break;
            case 3:
                System.out.println((char) 27 + "[33m ************ GOOD BYE ****************" + (char) 27 + "[0m");
                System.exit(0);
            default:
                System.out.println((char) 27 + "[31mInvalid" + (char) 27 + "[33m Invalid choice entered " + (char) 27 + "[0m" + (char) 27 + "[31mUser or Password!!" + (char) 27 + "[0m");
                break;
        }
    }

    private static void Login(String color, String profile) {
        int logInAttemps = 0;
        while (logInAttemps < 3) {
            System.out.println((char) 27 + "[" + color + "m____________________________________________" + (char) 27 + "[0m");
            System.out.println((char) 27 + "[" + color + "m_______________LOG IN AS " + profile + "______________" + (char) 27 + "[0m");
            System.out.print((char) 27 + "[" + color + "mEnter Username: " + (char) 27 + "[0m");
            String user = input.next();
            System.out.print((char) 27 + "[" + color + "mEnter Password: " + (char) 27 + "[0m");
            String pass = input.next();
            System.out.println((char) 27 + "[" + color + "m____________________________________________" + (char) 27 + "[0m");

            if (user.equalsIgnoreCase("admin") && pass.equalsIgnoreCase("admin")) {
                Staff();
            } else {
                System.out.println((char) 27 + "[31mInvalid" + (char) 27 + "[36m Admin " + (char) 27 + "[0m" + (char) 27 + "[31mUser or Password!!" + (char) 27 + "[0m");
                logInAttemps++;
            }
        }
    }

    public static void Staff() {
        System.out.println("Welcome to parking space management system");
        Map<String, Vehicle> vehiclesList = new HashMap<String, Vehicle>();
        while (true) {
            parkingOperations(vehiclesList);
        }
    }

    private static void parkingOperations(Map<String, Vehicle> vehiclesList) {
        Vehicle vehicle = new Vehicle();

        System.out.println(
                "Enter 1 for parking vehicle\nPress 2 for exiting vehicle\nPress 3 for showing status of parking space\n4 for exit");
        Scanner input = new Scanner(System.in);
        switch (input.next()) {
            case "1":
                getVehicleDetails(input, vehicle, vehiclesList);
                ParkingSpaceManager.assignParkingSlot(vehicle);
                break;
            case "2":
                System.out.println("Enter vehicle number:\n");
                Vehicle v = vehiclesList.get(input.next());

                ParkingSpaceManager.deAllocateParkingSlot(v);
                break;
            case "3":
                ParkingSpaceManager.parkingSpaceStatus();
                break;
            case "4":
                System.out.println("Thankyou for using our parking management system");
                ParkingSpaceManager.parkingSpaceStatus();
                System.exit(1);
                break;
            default:
                System.out.println("Wrong input! Try Again");
        }
    }

    private static void getVehicleDetails(Scanner input, Vehicle vehicle, Map<String, Vehicle> vehiclesList) {
        String licenseNumber;
        String type;
        System.out.println("Enter vehicle number:\n");
        licenseNumber = input.next();
        System.out.println("Enter vehicle type:<FOUR_WHEELER/TWO_WHEELER>\n");
        type = input.next();
        vehicle.setLicenseNumber(licenseNumber);
        vehicle.setType(type);
        vehiclesList.put(licenseNumber, vehicle);

    }
}
