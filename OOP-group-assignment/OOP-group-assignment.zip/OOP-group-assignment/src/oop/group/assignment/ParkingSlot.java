package oop.group.assignment;

public class ParkingSlot {

    public static Double HOURLY_4_WHEELER_CHARGE = 50.0;
    public static Double HOURLY_2_WHEELER_CHARGE = 20.0;
    public static Integer TWO_WHEELER_SLOTS_COUNT = 0;
    public static Integer FOUR_WHEELER_SLOTS_COUNT = 0;
}
