package oop.group.assignment;

public class Owners {
    
}
